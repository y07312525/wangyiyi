matri<-function(matrix1,matrxi2,num,nrow,ncol)
{
  for(i in 1:nrow)
  {
    for(j in 1:ncol)
    {
      if(num==1)
        matrix1[i,j]<-matrix1[i,j]+matrxi2[i,j]
      if(num3==2)
        matrix1[i,j]<-matrix1[i,j]-matrxi2[i,j]
      if(num3==3)
        matrix1[i,j]<-matrix1[i,j]*matrix2[i,j]
      if(num3==4)
        matri1x[i,j]<-matrix1[i,j]/matrix2[i,j]
      if(num3==5)
        matri1x[i,j]<-matrix1[i,j]%%matrix2[i,j]
    }
  }
  return(matrix1)
}
